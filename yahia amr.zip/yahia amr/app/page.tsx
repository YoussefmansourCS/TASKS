'use client';

import { useState } from 'react';
import { Menu, X, Github, Linkedin, Mail, Phone, MapPin, Award, Briefcase, Code } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

const navigation = [
  { name: 'About', href: '#about' },
  { name: 'Experience', href: '#experience' },
  { name: 'Skills', href: '#skills' },
  { name: 'Education', href: '#education' },
  { name: 'Contact', href: '#contact' },
];

export default function Home() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollToSection = (href: string) => {
    setMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex-shrink-0">
              <h1 className="text-2xl font-bold text-primary">YAF</h1>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-1">
              {navigation.map((item) => (
                <button
                  key={item.name}
                  onClick={() => scrollToSection(item.href)}
                  className="px-3 py-2 text-sm font-medium text-foreground hover:text-primary transition-colors"
                >
                  {item.name}
                </button>
              ))}
            </div>

            {/* Mobile Navigation Button */}
            <div className="md:hidden">
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="inline-flex items-center justify-center p-2 rounded-md text-foreground hover:bg-muted"
              >
                {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>

          {/* Mobile Navigation Menu */}
          {mobileMenuOpen && (
            <div className="md:hidden pb-4">
              {navigation.map((item) => (
                <button
                  key={item.name}
                  onClick={() => scrollToSection(item.href)}
                  className="block w-full text-left px-3 py-2 text-base font-medium text-foreground hover:bg-muted rounded-md"
                >
                  {item.name}
                </button>
              ))}
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative px-4 py-20 md:py-32 overflow-hidden">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <h2 className="text-5xl md:text-6xl font-bold text-foreground leading-tight">
                  Yahia Amr Fathy
                </h2>
                <p className="text-xl md:text-2xl text-primary font-semibold">
                  Autotronics Specialist
                </p>
              </div>
              <p className="text-lg text-muted-foreground leading-relaxed max-w-lg">
                Dedicated automotive professional with expertise in vehicle maintenance, autotronics systems, and automotive technology. Passionate about delivering high-quality automotive solutions with precision and excellence.
              </p>
              <div className="flex flex-wrap gap-3 pt-4">
                <Button 
                  onClick={() => scrollToSection('#contact')}
                  className="bg-primary text-primary-foreground hover:bg-primary/90"
                >
                  Get in Touch
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => scrollToSection('#experience')}
                >
                  View Work
                </Button>
              </div>
            </div>
            <div className="hidden md:flex items-center justify-center">
              <div className="relative w-64 h-64 rounded-2xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center border border-primary/30">
                <Briefcase size={120} className="text-primary/40" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="px-4 py-20 bg-card/50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold mb-12 text-foreground">About Me</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="p-8 border border-border bg-background/50">
              <h3 className="text-2xl font-semibold text-primary mb-4">Professional Summary</h3>
              <p className="text-muted-foreground leading-relaxed">
                Graduate from the Faculty of Industrial Technology and Energy at Delta Technological University with specialized knowledge in autotronics systems. Experienced automotive professional with hands-on expertise in vehicle maintenance, diagnostics, and repair operations. Committed to staying current with automotive industry advancements and best practices.
              </p>
            </Card>
            <Card className="p-8 border border-border bg-background/50">
              <h3 className="text-2xl font-semibold text-primary mb-4">Key Strengths</h3>
              <ul className="space-y-3">
                {[
                  'Vehicle Maintenance & Repair',
                  'Autotronics Systems Expertise',
                  'Automotive Diagnostics',
                  'Technical Problem Solving',
                  'Customer Service Excellence',
                  'Continuous Learning Mindset'
                ].map((strength) => (
                  <li key={strength} className="flex items-center gap-3 text-muted-foreground">
                    <div className="w-2 h-2 rounded-full bg-primary" />
                    {strength}
                  </li>
                ))}
              </ul>
            </Card>
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section id="experience" className="px-4 py-20">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold mb-12 text-foreground">Professional Experience</h2>
          <div className="space-y-8">
            <Card className="p-8 border-l-4 border-l-primary border border-border bg-background hover:shadow-lg transition-shadow">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 mt-1">
                  <Briefcase className="w-6 h-6 text-primary" />
                </div>
                <div className="flex-grow">
                  <h3 className="text-2xl font-semibold text-foreground">Salvador Auto Repair Center</h3>
                  <p className="text-primary font-semibold mt-1">Automotive Technician</p>
                  <p className="text-sm text-muted-foreground mt-1">Cairo, Egypt</p>
                  <p className="text-muted-foreground mt-4 leading-relaxed">
                    Specialized in comprehensive vehicle maintenance and repair operations. Performed diagnostic testing, troubleshooting, and repairs on various automotive systems including engine, transmission, electrical, and autotronics components. Maintained high standards of workmanship and customer satisfaction.
                  </p>
                  <div className="flex flex-wrap gap-2 mt-4">
                    {['Vehicle Diagnostics', 'Engine Repair', 'System Troubleshooting', 'Quality Assurance'].map((tag) => (
                      <span key={tag} className="px-3 py-1 bg-primary/10 text-primary text-sm rounded-full">
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="px-4 py-20 bg-card/50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold mb-12 text-foreground">Technical Skills & Expertise</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                icon: Code,
                title: 'Automotive Systems',
                skills: ['Engine Management', 'Electrical Systems', 'Transmission Systems', 'Brake Systems', 'Suspension Systems']
              },
              {
                icon: Briefcase,
                title: 'Specialized Services',
                skills: ['Vehicle Diagnostics', 'Preventive Maintenance', 'Repair & Restoration', 'System Troubleshooting', 'Quality Control']
              },
              {
                icon: Award,
                title: 'Professional Competencies',
                skills: ['Problem Analysis', 'Technical Documentation', 'Customer Communication', 'Safety Compliance', 'Industry Standards']
              }
            ].map((category) => {
              const IconComponent = category.icon;
              return (
                <Card key={category.title} className="p-6 border border-border bg-background hover:shadow-lg transition-shadow">
                  <div className="flex items-center gap-3 mb-4">
                    <IconComponent className="w-8 h-8 text-primary" />
                    <h3 className="text-lg font-semibold text-foreground">{category.title}</h3>
                  </div>
                  <ul className="space-y-2">
                    {category.skills.map((skill) => (
                      <li key={skill} className="text-muted-foreground flex items-center gap-2">
                        <div className="w-1.5 h-1.5 rounded-full bg-primary" />
                        {skill}
                      </li>
                    ))}
                  </ul>
                </Card>
              );
            })}
          </div>

          {/* Language Proficiency */}
          <div className="mt-12 bg-background border border-border rounded-lg p-8">
            <h3 className="text-2xl font-semibold text-foreground mb-6">Language Proficiency</h3>
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h4 className="font-semibold text-foreground mb-3">English</h4>
                <div className="flex items-center gap-3">
                  <div className="flex-grow bg-border rounded-full h-3 overflow-hidden">
                    <div className="bg-primary h-full" style={{ width: '80%' }} />
                  </div>
                  <span className="text-sm font-semibold text-primary">B2 Level</span>
                </div>
                <p className="text-sm text-muted-foreground mt-2">Upper Intermediate - Professional communication and technical discussions</p>
              </div>
              <div>
                <h4 className="font-semibold text-foreground mb-3">Arabic</h4>
                <div className="flex items-center gap-3">
                  <div className="flex-grow bg-border rounded-full h-3 overflow-hidden">
                    <div className="bg-accent h-full" style={{ width: '100%' }} />
                  </div>
                  <span className="text-sm font-semibold text-accent">Native</span>
                </div>
                <p className="text-sm text-muted-foreground mt-2">Fluent - Native speaker with full proficiency</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Education Section */}
      <section id="education" className="px-4 py-20">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold mb-12 text-foreground">Education & Certifications</h2>
          <div className="space-y-6">
            <Card className="p-8 border-l-4 border-l-accent border border-border bg-background">
              <div className="flex items-start gap-4">
                <Award className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
                <div>
                  <h3 className="text-2xl font-semibold text-foreground">Faculty of Industrial Technology and Energy</h3>
                  <p className="text-accent font-semibold mt-1">Delta Technological University</p>
                  <p className="text-muted-foreground mt-2">Degree focused on industrial technology and energy systems with specialized coursework in automotive technology and engineering principles.</p>
                </div>
              </div>
            </Card>

            <Card className="p-8 border-l-4 border-l-primary border border-border bg-background">
              <div className="flex items-start gap-4">
                <Award className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                <div>
                  <h3 className="text-2xl font-semibold text-foreground">Autotech Exhibition 2024</h3>
                  <p className="text-primary font-semibold mt-1">Cairo International Convention Center</p>
                  <p className="text-muted-foreground mt-2">Attended prestigious automotive technology exhibition, gaining exposure to latest advancements in autotronics systems, diagnostic equipment, and industry best practices.</p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="px-4 py-20 bg-card/50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold mb-12 text-foreground text-center">Get In Touch</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="p-8 text-center border border-border bg-background hover:shadow-lg transition-shadow">
              <Mail className="w-8 h-8 text-primary mx-auto mb-4" />
              <h3 className="font-semibold text-foreground mb-2">Email</h3>
              <p className="text-muted-foreground text-sm">
                <a href="mailto:contact@example.com" className="text-primary hover:underline">
                  yahia.amr.fathy@example.com
                </a>
              </p>
            </Card>

            <Card className="p-8 text-center border border-border bg-background hover:shadow-lg transition-shadow">
              <Phone className="w-8 h-8 text-primary mx-auto mb-4" />
              <h3 className="font-semibold text-foreground mb-2">Phone</h3>
              <p className="text-muted-foreground text-sm">
                <a href="tel:+201000000000" className="text-primary hover:underline">
                  +20 (1) 000 000 000
                </a>
              </p>
            </Card>

            <Card className="p-8 text-center border border-border bg-background hover:shadow-lg transition-shadow">
              <MapPin className="w-8 h-8 text-primary mx-auto mb-4" />
              <h3 className="font-semibold text-foreground mb-2">Location</h3>
              <p className="text-muted-foreground text-sm">Cairo, Egypt</p>
            </Card>
          </div>

          {/* Social Links */}
          <div className="mt-12 flex justify-center gap-6">
            <a href="#" className="p-3 rounded-lg bg-primary/10 text-primary hover:bg-primary hover:text-primary-foreground transition-colors">
              <Linkedin size={24} />
            </a>
            <a href="#" className="p-3 rounded-lg bg-primary/10 text-primary hover:bg-primary hover:text-primary-foreground transition-colors">
              <Github size={24} />
            </a>
            <a href="mailto:yahia.amr.fathy@example.com" className="p-3 rounded-lg bg-primary/10 text-primary hover:bg-primary hover:text-primary-foreground transition-colors">
              <Mail size={24} />
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="px-4 py-8 border-t border-border bg-background/50">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-muted-foreground text-sm">© 2024 Yahia Amr Fathy. All rights reserved.</p>
          <p className="text-muted-foreground text-sm">Autotronics Specialist | Automotive Professional</p>
        </div>
      </footer>
    </div>
  );
}
